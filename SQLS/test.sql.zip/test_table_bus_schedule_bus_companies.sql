
-- --------------------------------------------------------

--
-- Table structure for table `bus_schedule_bus_companies`
--

CREATE TABLE `bus_schedule_bus_companies` (
  `bus_schedule_company_id` int(11) NOT NULL,
  `bus_companies_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `bus_schedule_bus_companies`:
--   `bus_companies_id`
--       `bus_companies` -> `id`
--
