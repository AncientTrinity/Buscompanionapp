
-- --------------------------------------------------------

--
-- Table structure for table `mileage_of_trip`
--

CREATE TABLE `mileage_of_trip` (
  `id` int(11) NOT NULL,
  `beginning_location_id` int(11) DEFAULT NULL,
  `destination_location_id` int(11) DEFAULT NULL,
  `total_miles` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `mileage_of_trip`:
--   `beginning_location_id`
--       `locations_of_stop` -> `id`
--   `destination_location_id`
--       `locations_of_stop` -> `id`
--

--
-- Dumping data for table `mileage_of_trip`
--

INSERT INTO `mileage_of_trip` (`id`, `beginning_location_id`, `destination_location_id`, `total_miles`) VALUES
(1, 1, 2, 23),
(2, 1, 2, 27),
(3, 1, 2, 39),
(4, 1, 2, 24),
(5, 1, 2, 51),
(6, 1, 2, 24),
(7, 1, 2, 51),
(8, 1, 2, 39),
(9, 1, 2, 32);
