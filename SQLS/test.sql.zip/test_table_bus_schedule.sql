
-- --------------------------------------------------------

--
-- Table structure for table `bus_schedule`
--

CREATE TABLE `bus_schedule` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `beginning_location_id` int(11) DEFAULT NULL,
  `destination_location_id` int(11) DEFAULT NULL,
  `bus_departure_time` time DEFAULT NULL,
  `bus_arrival_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `bus_schedule`:
--   `id`
--       `ticket_info` -> `route_id`
--   `beginning_location_id`
--       `locations_of_stop` -> `id`
--   `destination_location_id`
--       `locations_of_stop` -> `id`
--   `company_id`
--       `bus_schedule_bus_companies` -> `bus_schedule_company_id`
--

--
-- Dumping data for table `bus_schedule`
--

INSERT INTO `bus_schedule` (`id`, `company_id`, `beginning_location_id`, `destination_location_id`, `bus_departure_time`, `bus_arrival_time`) VALUES
(1, 8, 1, 2, '08:00:00', '08:55:00'),
(2, 7, 2, 3, '09:00:00', '10:00:00'),
(3, 6, 3, 4, '10:00:00', '11:30:00'),
(4, 5, 4, 5, '05:00:00', '06:00:00'),
(5, 4, 5, 6, '03:00:00', '04:10:00'),
(6, 3, 6, 7, '01:00:00', '02:15:00'),
(7, 2, 8, 1, '02:00:00', '04:00:00'),
(8, 1, 1, 2, '03:30:00', '05:00:00');
