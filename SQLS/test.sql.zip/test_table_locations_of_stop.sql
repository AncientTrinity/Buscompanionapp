
-- --------------------------------------------------------

--
-- Table structure for table `locations_of_stop`
--

CREATE TABLE `locations_of_stop` (
  `id` int(11) NOT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `locations_of_stop`:
--

--
-- Dumping data for table `locations_of_stop`
--

INSERT INTO `locations_of_stop` (`id`, `location`) VALUES
(1, 'Belize'),
(2, 'Belmopan'),
(3, 'Cayo'),
(4, 'Punta Gorda'),
(5, 'Dangriga'),
(6, 'Stann Creek'),
(7, 'Corozal'),
(8, 'Orange Walk');
