
--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus_companies`
--
ALTER TABLE `bus_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus_schedule`
--
ALTER TABLE `bus_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beginning_location_id` (`beginning_location_id`,`destination_location_id`),
  ADD KEY `destination_location_id` (`destination_location_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `bus_schedule_bus_companies`
--
ALTER TABLE `bus_schedule_bus_companies`
  ADD PRIMARY KEY (`bus_schedule_company_id`) USING BTREE,
  ADD KEY `bus_companies_id` (`bus_companies_id`);

--
-- Indexes for table `locations_of_stop`
--
ALTER TABLE `locations_of_stop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mileage_of_trip`
--
ALTER TABLE `mileage_of_trip`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beginning_location_id` (`beginning_location_id`,`destination_location_id`),
  ADD KEY `destination_location_id` (`destination_location_id`);

--
-- Indexes for table `ticket_info`
--
ALTER TABLE `ticket_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_price` (`ticket_price`),
  ADD KEY `route_id` (`route_id`);

--
-- Indexes for table `ticket_orders`
--
ALTER TABLE `ticket_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- Indexes for table `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bus_schedule`
--
ALTER TABLE `bus_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users_info`
--
ALTER TABLE `users_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bus_schedule`
--
ALTER TABLE `bus_schedule`
  ADD CONSTRAINT `bus_schedule_ibfk_1` FOREIGN KEY (`id`) REFERENCES `ticket_info` (`route_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bus_schedule_ibfk_2` FOREIGN KEY (`beginning_location_id`) REFERENCES `locations_of_stop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bus_schedule_ibfk_3` FOREIGN KEY (`destination_location_id`) REFERENCES `locations_of_stop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bus_schedule_ibfk_4` FOREIGN KEY (`company_id`) REFERENCES `bus_schedule_bus_companies` (`bus_schedule_company_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bus_schedule_bus_companies`
--
ALTER TABLE `bus_schedule_bus_companies`
  ADD CONSTRAINT `bus_schedule_bus_companies_ibfk_1` FOREIGN KEY (`bus_companies_id`) REFERENCES `bus_companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mileage_of_trip`
--
ALTER TABLE `mileage_of_trip`
  ADD CONSTRAINT `mileage_of_trip_ibfk_1` FOREIGN KEY (`beginning_location_id`) REFERENCES `locations_of_stop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mileage_of_trip_ibfk_2` FOREIGN KEY (`destination_location_id`) REFERENCES `locations_of_stop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ticket_info`
--
ALTER TABLE `ticket_info`
  ADD CONSTRAINT `ticket_info_ibfk_1` FOREIGN KEY (`ticket_price`) REFERENCES `mileage_of_trip` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ticket_orders`
--
ALTER TABLE `ticket_orders`
  ADD CONSTRAINT `ticket_orders_ibfk_1` FOREIGN KEY (`id`) REFERENCES `ticket_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ticket_orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table bus_companies
--

--
-- Metadata for table bus_schedule
--

--
-- Metadata for table bus_schedule_bus_companies
--

--
-- Metadata for table locations_of_stop
--

--
-- Metadata for table mileage_of_trip
--

--
-- Metadata for table ticket_info
--

--
-- Metadata for table ticket_orders
--

--
-- Metadata for table users_info
--

--
-- Metadata for database test
--

--
-- Dumping data for table `pma__pdf_pages`
--

INSERT INTO `pma__pdf_pages` (`db_name`, `page_descr`) VALUES
('test', 'BCA');

SET @LAST_PAGE = LAST_INSERT_ID();

--
-- Dumping data for table `pma__table_coords`
--

INSERT INTO `pma__table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES
('test', 'bus_companies', @LAST_PAGE, 179, 452),
('test', 'bus_schedule', @LAST_PAGE, 545, 268),
('test', 'bus_schedule_bus_companies', @LAST_PAGE, 135, 284),
('test', 'locations_of_stop', @LAST_PAGE, 558, 8),
('test', 'mileage_of_trip', @LAST_PAGE, 842, 84),
('test', 'ticket_info', @LAST_PAGE, 859, 311),
('test', 'ticket_orders', @LAST_PAGE, 1222, 311),
('test', 'users_info', @LAST_PAGE, 1180, 524);
