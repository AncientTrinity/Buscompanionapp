
-- --------------------------------------------------------

--
-- Table structure for table `ticket_info`
--

CREATE TABLE `ticket_info` (
  `id` int(11) NOT NULL,
  `route_id` int(11) DEFAULT NULL,
  `ticket_price` int(11) DEFAULT NULL,
  `number_of_tickets_available` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `ticket_info`:
--   `ticket_price`
--       `mileage_of_trip` -> `id`
--
