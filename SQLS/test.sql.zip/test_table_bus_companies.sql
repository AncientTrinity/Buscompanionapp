
-- --------------------------------------------------------

--
-- Table structure for table `bus_companies`
--

CREATE TABLE `bus_companies` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `bus_companies`:
--

--
-- Dumping data for table `bus_companies`
--

INSERT INTO `bus_companies` (`id`, `company_name`) VALUES
(1, 'James'),
(2, 'McFadzean'),
(3, 'Westline'),
(4, 'Floralia'),
(5, 'Morales'),
(6, 'Shaws'),
(7, 'Russel'),
(8, 'Brads'),
(9, 'Speed Busline');
